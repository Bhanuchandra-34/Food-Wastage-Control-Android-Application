package com.bhanu.foodapplication.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.bhanu.foodapplication.R
import com.bhanu.foodapplication.adapter.OrderAdapter
import com.bhanu.foodapplication.constant.Variables
import com.bhanu.foodapplication.databinding.ActivityAdminOdersListBinding
import com.bhanu.foodapplication.model.Order
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class AdminOdersList : AppCompatActivity() {

    private lateinit var binding: ActivityAdminOdersListBinding
    private val firestore by lazy { FirebaseFirestore.getInstance() }
    private val auth by lazy { FirebaseAuth.getInstance() }
    private val orderList = mutableListOf<Order>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdminOdersListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = getColor(R.color.app_color)
        setupRecyclerView()

        fetchOrders()
    }

    private fun setupRecyclerView() {
        val adapter = OrderAdapter(orderList)
        binding.ordersRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.ordersRecyclerView.adapter = adapter
    }

    private fun fetchOrders() {
        val userEmail = auth.currentUser?.email

        if (userEmail != null) {
            firestore.collection(Variables.ORDER_LIST)
                .whereEqualTo(Variables.RESTURENT_Id, userEmail)
                .get()
                .addOnSuccessListener { documents ->
                    orderList.clear()
                    for (document in documents) {
                        val order = document.toObject(Order::class.java)
                        orderList.add(order)
                    }

                    binding.ordersRecyclerView.adapter?.notifyDataSetChanged()
                }
                .addOnFailureListener { exception ->
                }
        } else {
        }
    }
}
