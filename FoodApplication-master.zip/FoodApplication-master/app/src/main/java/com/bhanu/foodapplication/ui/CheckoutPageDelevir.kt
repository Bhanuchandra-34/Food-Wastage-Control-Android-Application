package com.bhanu.foodapplication.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bhanu.foodapplication.R
import com.bhanu.foodapplication.constant.Constant
import com.bhanu.foodapplication.constant.Variables
import com.bhanu.foodapplication.databinding.ActivityCheckoutPageDelevirBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class CheckoutPageDelevir : AppCompatActivity() {

    private lateinit var binding: ActivityCheckoutPageDelevirBinding
    private lateinit var firestore: FirebaseFirestore
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCheckoutPageDelevirBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = getColor(R.color.app_color)
        firestore = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        val userEmail = auth.currentUser?.email

        if (userEmail != null) {
            fetchUserData(userEmail)
        }

        binding.back4.setOnClickListener {
            onBackPressed()
        }

        binding.paymentDone.setOnClickListener {
            Constant.showToast(this,Variables.PAYMENT_SUCCESS)
            finish()
        }
    }

    private fun fetchUserData(email: String) {
        firestore.collection(Variables.USERS).document(email).get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    val name = document.getString(Variables.USER_PROFILE_NAME) !!
                    val userEmail = document.getString(Variables.USER_PROFILE_EMAIl) !!
                    val city = document.getString(Variables.USER_PROFILE_CITY) !!
                    val place = document.getString(Variables.USER_PROFILE_PLACE) !!

                    binding.reciverName.text = name
                    binding.email.text = userEmail
                    binding.dilverAddreess.text = "$place,$city"
                } else {
                    Constant.showToast(this, Variables.USER_NOT_FOUND)
                }
            }
            .addOnFailureListener { e ->
                Constant.showToast(this, Variables.USER_NOT_FOUND_FAILED)
            }
    }
}
