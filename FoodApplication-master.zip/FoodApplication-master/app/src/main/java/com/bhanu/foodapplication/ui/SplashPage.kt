package com.bhanu.foodapplication.ui

import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.NotificationManagerCompat
import androidx.core.view.WindowCompat
import com.bhanu.foodapplication.MainActivity
import com.bhanu.foodapplication.R
import com.bhanu.foodapplication.constant.Constant
import com.bhanu.foodapplication.constant.Variables
import com.bhanu.foodapplication.databinding.ActivitySplashPageBinding
import com.google.firebase.auth.FirebaseAuth
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SplashPage : AppCompatActivity() {

    private lateinit var binding: ActivitySplashPageBinding
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        binding = ActivitySplashPageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = getColor(R.color.app_color)

        auth = FirebaseAuth.getInstance()

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            requestNotificationPermission()
        }

        GlobalScope.launch {
            delay(2000)
            checkUserStatus()
        }
    }

    private fun checkUserStatus() {
        val currentUser = auth.currentUser
        if (currentUser != null) {
            navigateToMainActivity()
        } else {
            navigateToLoginPage()
        }
    }

    private fun navigateToMainActivity() {
        val intent = Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }

    private fun navigateToLoginPage() {
        val intent = Intent(this, LoginPage::class.java)
        startActivity(intent)
        finish()
    }

    private fun requestNotificationPermission() {
        if (NotificationManagerCompat.from(this).areNotificationsEnabled()) {
            return
        } else {
            Constant.showToast(this,Variables.NOTIFICATION)
            val intent = Intent(android.provider.Settings.ACTION_APP_NOTIFICATION_SETTINGS)
            intent.putExtra(android.provider.Settings.EXTRA_APP_PACKAGE, packageName)
            startActivity(intent)
        }
    }
}
