package com.bhanu.foodapplication.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "food_table")
data class FoodItem(
    val foodName: String = "",
    val foodQuantity: String = "",
    val imageUrl: String = "",
    val foodPlace: String = "",
    val foodAmount: String = "",
    @PrimaryKey val foodId: String = "",
    val foodCity: String = "",
    val restaurantId: String = ""
)
