package com.bhanu.foodapplication.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bhanu.foodapplication.R
import com.bhanu.foodapplication.constant.Constant
import com.bhanu.foodapplication.constant.Variables
import com.bhanu.foodapplication.databinding.ActivityEditProfilePageBinding
import com.google.firebase.firestore.FirebaseFirestore

class EditProfilePage : AppCompatActivity() {

    private lateinit var binding: ActivityEditProfilePageBinding

    private lateinit var firestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {

        super.onCreate(savedInstanceState)
        binding = ActivityEditProfilePageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = getColor(R.color.app_color)
        firestore = FirebaseFirestore.getInstance()

        val email = intent.getStringExtra(Variables.USER_PROFILE_EMAIl) ?: return
        val name = intent.getStringExtra(Variables.USER_PROFILE_NAME)
        val city = intent.getStringExtra(Variables.USER_PROFILE_CITY)
        val place = intent.getStringExtra(Variables.USER_PROFILE_PLACE)
        val friendName = intent.getStringExtra(Variables.USER_PROFILE_FNAME)
        val petName = intent.getStringExtra(Variables.USER_PROFILE_PNAME)
        val contactNumber=intent.getStringExtra(Variables.CONTACT_NUMBER)

        binding.nameEditText.setText(name)
        binding.emailEdt.setText(email)
        binding.cityEdt.setText(city)
        binding.numberContact.setText(contactNumber)
        binding.plceEdt.setText(place)
        binding.friendEdt.setText(friendName)
        binding.petedt.setText(petName)

        binding.Update.setOnClickListener {
            val updatedName = binding.nameEditText.text.toString().trim()
            val updatedCity = binding.cityEdt.text.toString().trim()
            val updatedPlace = binding.plceEdt.text.toString().trim()
            val updatedFriendName = binding.friendEdt.text.toString().trim()
            val num= binding.numberContact.text.toString().trim()
            val updatedPetName = binding.petedt.text.toString().trim()
            if (updatedName.isEmpty() || updatedCity.isEmpty() || updatedPlace.isEmpty() ||
                updatedFriendName.isEmpty() || updatedPetName.isEmpty()) {
                Constant.showToast(this, Variables.ALL_THE_FIELD_ARE_MANDATORY_TO_FILL)
                return@setOnClickListener
            }
            Constant.showLoadingDialog(this)

            val updates = mapOf(
                Variables.USER_PROFILE_NAME to updatedName,
                Variables.USER_PROFILE_CITY to updatedCity,
                Variables.USER_PROFILE_PLACE to updatedPlace,
                Variables.CONTACT_NUMBER to num,
                Variables.USER_PROFILE_FNAME to updatedFriendName,
                Variables.USER_PROFILE_PNAME to updatedPetName
            )
                        firestore.collection(Variables.USERS).document(email)
                .update(updates)
                .addOnSuccessListener {
                    Constant.dismissLoadingDialog()
                    val intent = Intent(this, ProfilePage::class.java).apply {
                        flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    }
                    startActivity(intent)
                    Constant.showToast(this, Variables.UPLOAD_SUCCESFULL)
                }
                .addOnFailureListener { e ->
                    Constant.dismissLoadingDialog()
                    Constant.showToast(this, Variables.FAILED_UPDATE)
                }
        }
    }
}
