package com.bhanu.foodapplication.room

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import com.bhanu.foodapplication.constant.Variables
import com.bhanu.foodapplication.model.FoodItem

@Dao
interface FoodDao {
    @Insert
    suspend fun insertFood(food: FoodItem)

    @Query(Variables.DATABASE_QUERY)
    suspend fun getAllFood(): List<FoodItem>

    @Delete
    suspend fun deleteFood(food: FoodItem)

    @Query("SELECT EXISTS(SELECT 1 FROM food_table WHERE foodId = :foodId)")
    suspend fun isFoodInCart(foodId: String): Boolean

    @Query("SELECT * FROM food_table WHERE foodId = :foodId LIMIT 1")
    suspend fun getFoodById(foodId: String): FoodItem?

    @Query("DELETE FROM food_table")
    suspend fun clearCart()

}
