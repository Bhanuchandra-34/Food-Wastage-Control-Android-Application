package com.bhanu.foodapplication.ui

import android.content.Intent
import android.os.Bundle

import androidx.appcompat.app.AppCompatActivity
import com.bhanu.foodapplication.MainActivity
import com.bhanu.foodapplication.R
import com.bhanu.foodapplication.constant.Variables
import com.bhanu.foodapplication.databinding.ActivityProfilePageBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore


class ProfilePage : AppCompatActivity() {

    private lateinit var binding:ActivityProfilePageBinding

    private lateinit var auth:FirebaseAuth
    private lateinit var firestore: FirebaseFirestore

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityProfilePageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = getColor(R.color.app_color)

        auth=FirebaseAuth.getInstance()
        firestore=FirebaseFirestore.getInstance()

        binding.back2.setOnClickListener {
            val intent= Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        binding.edt.setOnClickListener {
            val intent = Intent(this, EditProfilePage::class.java)

            val currentUser = auth.currentUser
            if (currentUser != null) {
                val userEmail = currentUser.email

                firestore.collection(Variables.USERS).document(userEmail!!).get().addOnSuccessListener { document ->
                    if (document != null && document.exists()) {
                        val name = document.getString(Variables.USER_PROFILE_NAME)!!
                        val email = document.getString(Variables.USER_PROFILE_EMAIl)!!
                        val role = document.getLong(Variables.USER_PROFILE_ROLE)!!.toInt()
                        val city = document.getString(Variables.USER_PROFILE_CITY)!!
                        val place = document.getString(Variables.USER_PROFILE_PLACE)
                        val contactNumber=document.getString(Variables.CONTACT_NUMBER)
                        val friendName = document.getString(Variables.USER_PROFILE_FNAME)!!
                        val petName = document.getString(Variables.USER_PROFILE_PNAME)!!

                        intent.apply {
                            putExtra(Variables.USER_PROFILE_NAME, name)
                            putExtra(Variables.USER_PROFILE_EMAIl, email)
                            putExtra(Variables.USER_PROFILE_ROLE, role)
                            putExtra(Variables.USER_PROFILE_CITY, city)
                            putExtra(Variables.USER_PROFILE_PLACE, place)
                            putExtra(Variables.CONTACT_NUMBER,contactNumber)
                            putExtra(Variables.USER_PROFILE_FNAME, friendName)
                            putExtra(Variables.USER_PROFILE_PNAME, petName)
                        }
                        startActivity(intent)
                    }
                }
            }
        }


        val currentUser=auth.currentUser
        if (currentUser!=null){
            val userEmail=currentUser.email

            firestore.collection(Variables.USERS).document(userEmail!!).get().addOnSuccessListener{document->

                if (document != null && document.exists()) {
                    val name = document.getString(Variables.USER_PROFILE_NAME) !!
                    val email=document.getString(Variables.USER_PROFILE_EMAIl)!!
                    val role= document.getLong(Variables.USER_PROFILE_ROLE)!!.toInt()
                    val city=document.getString(Variables.USER_PROFILE_CITY)!!
                    val place=document.getString(Variables.USER_PROFILE_PLACE)
                    val cotact=document.getString(Variables.CONTACT_NUMBER)
                    val friendName=document.getString(Variables.USER_PROFILE_FNAME)!!
                    val petName=document.getString(Variables.USER_PROFILE_PNAME)!!

                    val roleText = when (role) {
                       Variables.ONE -> Variables.DONOR
                        Variables.TWO-> Variables.USERS
                        else -> Variables.UNKNOWN_USER
                    }

                    binding.nameTxt.text = name
                    binding.emailTxt.text=email
                    binding.donarTxt.text=roleText
                    binding.cityTxt.text=city
                    binding.placeTxt.text=place
                    binding.friendTxt.text=friendName
                    binding.petTxt.text=petName
                    binding.contactNumber.text=cotact

                }
            }

        }


    }
}