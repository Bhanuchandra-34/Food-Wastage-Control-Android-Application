package com.bhanu.foodapplication.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.bhanu.foodapplication.R
import com.bhanu.foodapplication.constant.Variables
import com.bhanu.foodapplication.databinding.ItemOrderBinding
import com.bhanu.foodapplication.model.Order
import com.bhanu.foodapplication.ui.AdminOderListDetailPage
import com.bumptech.glide.Glide
import com.google.firebase.firestore.FirebaseFirestore

class OrderAdapter(private val orderList: MutableList<Order>) :
    RecyclerView.Adapter<OrderAdapter.OrderViewHolder>() {

    private val firestore = FirebaseFirestore.getInstance()

    inner class OrderViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val binding = ItemOrderBinding.bind(view)
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): OrderViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_order, parent, false)
        return OrderViewHolder(view)
    }

    override fun onBindViewHolder(holder: OrderViewHolder, position: Int) {
        val order = orderList[position]
        holder.binding.foodname.text = order.foodName
        holder.binding.foodQuantity.text = order.foodQuantity
        Glide.with(holder.itemView.context)
            .load(order.imageUrl)
            .into(holder.binding.img)

        holder.itemView.setOnClickListener{
            val intent=Intent(holder.itemView.context,AdminOderListDetailPage::class.java)
            intent.putExtra(Variables.FF_NN,order.foodName)
            intent.putExtra(Variables.FF_QQ,order.foodQuantity)
            intent.putExtra(Variables.FF_CC,order.foodCity)
            intent.putExtra(Variables.FF_PP,order.foodPlace)
            intent.putExtra(Variables.FF_AA,order.foodAmount)
            intent.putExtra(Variables.FF_IMG_URL,order.imageUrl)
            intent.putExtra(Variables.FF_ID,order.documentId)
            holder.itemView.context.startActivity(intent)
        }

        holder.binding.deleteButton.setOnClickListener {
            deleteOrder(order.documentId, position, holder)
        }
    }

    override fun getItemCount(): Int = orderList.size

    private fun deleteOrder(orderId: String, position: Int, holder: OrderViewHolder) {
        firestore.collection(Variables.ORDER_LIST)
            .document(orderId)
            .delete()
            .addOnSuccessListener {
                orderList.removeAt(position)
                notifyItemRemoved(position)
                Toast.makeText(
                    holder.itemView.context,
                    Variables.ODER_DELETED_SUCCESFULLY,
                    Toast.LENGTH_SHORT
                ).show()
            }
            .addOnFailureListener { exception ->
            }
    }
}
