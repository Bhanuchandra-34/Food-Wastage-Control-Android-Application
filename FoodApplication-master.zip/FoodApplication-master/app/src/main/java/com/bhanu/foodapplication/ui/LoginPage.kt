package com.bhanu.foodapplication.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.bhanu.foodapplication.MainActivity
import com.bhanu.foodapplication.R
import com.bhanu.foodapplication.constant.Constant
import com.bhanu.foodapplication.constant.Variables
import com.bhanu.foodapplication.databinding.ActivityLoginPageBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class LoginPage : AppCompatActivity() {

    private lateinit var binding: ActivityLoginPageBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityLoginPageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = getColor(R.color.app_color)
        ui()

    }

    private fun ui() {
        binding.signUp.setOnClickListener {
            val intent=Intent(this, RegisterPage::class.java)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
            startActivity(intent)
        }
        binding.login.setOnClickListener{
            if (validateData()) {
                loginUser()
            }
        }
    }

    private fun validateData() :Boolean{
        val email = binding.emailEditText.text.toString().trim()
        val password =binding. passwordEditText.text.toString().trim()
        if (email.isEmpty()) {
            Constant.showToast(this, Variables.EMAIL_REQUIRED)
            return false
        }
        if (password.isEmpty()) {
            Constant.showToast(this, Variables.PASSWORD_REQUIRED )
            return false
        }
        return true
    }

    private fun loginUser() {
        Constant.showLoadingDialog(this)
        val email = binding.emailEditText.text.toString().trim()
        val password = binding.passwordEditText.text.toString().trim()
        FirebaseAuth.getInstance().signInWithEmailAndPassword(email, password)
            .addOnCompleteListener { task ->
                Constant.dismissLoadingDialog()
                if (task.isSuccessful) {
                    val user = FirebaseAuth.getInstance().currentUser
                    if (user != null) {
                        FirebaseFirestore.getInstance().collection(Variables.USERS).document(user.email!!)
                            .get()
                            .addOnSuccessListener { document ->
                                if (document != null && document.exists()) {
                                    val role = document.getLong(Variables.USER_PROFILE_ROLE) !!
                                    val place=document.getString(Variables.USER_PROFILE_PLACE)!!
                                    val sharedPreferences = getSharedPreferences(Variables.MY_PREF, MODE_PRIVATE)
                                    sharedPreferences.edit()
                                        .putBoolean(Variables.IS_LOGGEDIN, true)
                                        .putInt(Variables.USER_ROLE, role.toInt())
                                        .putString(Variables.PLACE_F,place)
                                        .apply()

                                    Constant.showToast(this, Variables.LOGIN_SUSCESSFUL)

                                    navigateToHomePage()
                                } else {
                                    Constant.showToast(this, Variables.NOT_FOUND)
                                }
                            }
                            .addOnFailureListener { exception ->
                                Constant.showToast(this, exception.message.toString())
                            }
                    }
                } else {
                    Constant.showToast(this, task.exception?.message.toString())
                }
            }
            .addOnFailureListener { exception ->
                Constant.dismissLoadingDialog()
                Constant.showToast(this, exception.message.toString())
            }
    }


    private fun navigateToHomePage() {
        val intent=Intent(this, MainActivity::class.java)
        startActivity(intent)
        finish()
    }
}