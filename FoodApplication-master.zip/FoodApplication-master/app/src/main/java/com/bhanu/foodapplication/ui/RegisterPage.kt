package com.bhanu.foodapplication.ui

import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.appcompat.app.AppCompatActivity
import com.bhanu.foodapplication.R
import com.bhanu.foodapplication.constant.Constant
import com.bhanu.foodapplication.constant.Variables
import com.bhanu.foodapplication.databinding.ActivityRegisterPageBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class RegisterPage : AppCompatActivity() {

    private lateinit var binding: ActivityRegisterPageBinding
    private lateinit var auth: FirebaseAuth
    private lateinit var firestore: FirebaseFirestore
    private var isDialogShowing: Boolean = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityRegisterPageBinding.inflate(layoutInflater)
        window.statusBarColor = getColor(R.color.app_color)
        setContentView(binding.root)

        auth = FirebaseAuth.getInstance()
        firestore = FirebaseFirestore.getInstance()

        val dropDown: Spinner = findViewById(R.id.dropDown)
        val items = arrayOf(Variables.SELECT_ROLE, Variables.DONOR, Variables.USER)
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, items)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        dropDown.adapter = adapter

        ui()

    }

    private fun ui() {
        binding.register.setOnClickListener {
            if (validateData()) {
                registerUser()
            }
        }
    }

    private fun validateData(): Boolean {
        val name = binding.nameEditText.text.toString().trim()
        val email = binding.emailEditText.text.toString().trim()
        val password =binding. passwordEditText.text.toString().trim()
        val address = binding.addressEditText.text.toString().trim()
        val place = binding.placeEditText.text.toString().trim()
        val friendsName =binding. friendsNameEditText.text.toString().trim()
        val petName = binding.petNameEditText.text.toString().trim()
        val contactNumber=binding.numberContactText.text.toString().trim()
        val selectedRole = binding.dropDown.selectedItem.toString()


        if (name.isEmpty()) {
            Constant.showToast(this, Variables.NAME_REQUIRED)
            return false
        }

        if (email.isEmpty()) {
            Constant.showToast(this, Variables.EMAIL_REQUIRED)
            return false
        }

        if (password.isEmpty()) {
            Constant.showToast(this,Variables.PASSWORD_REQUIRED )
            return false
        }

        if (contactNumber.isEmpty()) {
            Constant.showToast(this, Variables.NUMBER_REQUIRED)
            return false
        } else if (contactNumber.length != 10) {
            Constant.showToast(this, Variables.MAXIMUM_TEN)
            return false
        } else if (!contactNumber.all { it.isDigit() }) {
            Constant.showToast(this, Variables.ONLY_MUMRIC)
            return false
        }

        if (address.isEmpty()) {
            Constant.showToast(this, Variables.ADDRESS_REQUIRED)
            return false
        }

        if (place.isEmpty()) {
            Constant.showToast(this, Variables.PLACE_REQUIRED)
            return false
        }

        if (friendsName.isEmpty()) {
            Constant.showToast(this, Variables.FRIENDS_NAME_REQUIRED)
            return false
        }

        if (petName.isEmpty()) {
            Constant.showToast(this, Variables.PET_NAME_REQUIRED)
            return false
        }

        if (selectedRole == Variables.SELECT_ROLE) {
            Constant.showToast(this, Variables.SPINNER)
            return false
        }

        return true
    }

    private fun registerUser() {
        Constant.showLoadingDialog(this)
        isDialogShowing = true

        val email = binding.emailEditText.text.toString().trim()
        val password = binding.passwordEditText.text.toString().trim()
        val name = binding.nameEditText.text.toString().trim()
        val address = binding.addressEditText.text.toString().trim()
        val place = binding.placeEditText.text.toString().trim()
        val contactNumber=binding.numberContactText.text.toString().trim()
        val friendsName = binding.friendsNameEditText.text.toString().trim()
        val petName = binding.petNameEditText.text.toString().trim()
        val selectedRole = binding.dropDown.selectedItem.toString()

        val roleValue = when (selectedRole) {
            Variables.DONOR -> Variables.ONE
            Variables.USER -> Variables.TWO
            else -> null
        }

        auth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(this) { task ->
                if (task.isSuccessful) {
                    val userId = auth.currentUser?.uid
                    val userMap = hashMapOf(
                        Variables.NAME to name,
                        Variables.EMAIl to email,
                        Variables.PASSWORD to password,
                        Variables.ADDRESS  to address,
                        Variables.PLACE to place,
                        Variables.CONTACT_NUMBER to contactNumber,
                        Variables.FRIEND_NAME to friendsName,
                        Variables.PET_NAME to petName,
                        Variables.USER_ID to userId,
                        Variables.SELECT_ROLE to roleValue
                    )
                    if (userId != null) {
                        firestore.collection(Variables.COLLECTION_NAME).document(email)
                            .set(userMap)
                            .addOnSuccessListener {
                                isDialogShowing = false
                                Constant.dismissLoadingDialog()
                                Constant.showToast(this, Variables.REGISTER_SUCESSFULL)
                                navigateToHomePage()
                            }
                            .addOnFailureListener {
                                Constant.showToast(this, Variables.FAILED_TO_REGISTER)
                            }
                    }
                } else {
                    isDialogShowing = false
                    Constant.dismissLoadingDialog()
                    Constant.showToast(this, "${Variables.FAILED_TO_REGISTER} ${task.exception?.message}")
                }
            }
    }

    private fun navigateToHomePage() {
        val intent = Intent(this, LoginPage::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)
        finish()
    }

    override fun onBackPressed() {
        super.onBackPressed()
        val intent= Intent(this,LoginPage::class.java)
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK)
        startActivity(intent)
    }

}