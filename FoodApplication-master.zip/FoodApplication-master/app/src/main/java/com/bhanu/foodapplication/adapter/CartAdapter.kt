package com.bhanu.foodapplication.adapter

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bhanu.foodapplication.databinding.AddToCartListItemBinding
import com.bhanu.foodapplication.model.FoodItem
import com.bumptech.glide.Glide

class CartAdapter(
    private val foodList: List<FoodItem>,
    private val onItemClick: (FoodItem) -> Unit,
    private val onDeleteClick: (FoodItem) -> Unit
) : RecyclerView.Adapter<CartAdapter.CartViewHolder>() {

    inner class CartViewHolder(private val binding: AddToCartListItemBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(food: FoodItem) {
            binding.foodname.text = food.foodName
            binding.foodQuantity.text = food.foodQuantity
            binding.delte.setOnClickListener {

            }
            Glide.with(binding.img.context)
                .load(food.imageUrl)
                .into(binding.img)

            binding.delte.setOnClickListener {
                onDeleteClick(food)
            }

            itemView.setOnClickListener {
                onItemClick(food)
            }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CartViewHolder {
        val binding = AddToCartListItemBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return CartViewHolder(binding)
    }

    override fun onBindViewHolder(holder: CartViewHolder, position: Int) {
        holder.bind(foodList[position])
    }

    override fun getItemCount(): Int = foodList.size
}
