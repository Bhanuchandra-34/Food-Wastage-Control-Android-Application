package com.bhanu.foodapplication

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.bhanu.foodapplication.adapter.FoodItemAdapter
import com.bhanu.foodapplication.adapter.NearByFoodAdapter
import com.bhanu.foodapplication.adapter.RestaurantOrderItem
import com.bhanu.foodapplication.constant.Constant
import com.bhanu.foodapplication.constant.Variables
import com.bhanu.foodapplication.databinding.ActivityMainBinding
import com.bhanu.foodapplication.model.FoodItem
import com.bhanu.foodapplication.ui.AddFoodItems
import com.bhanu.foodapplication.ui.AdminOdersList
import com.bhanu.foodapplication.ui.CartActivity
import com.bhanu.foodapplication.ui.LoginPage
import com.bhanu.foodapplication.ui.MyOrdersActivity
import com.bhanu.foodapplication.ui.ProfilePage
import com.bhanu.foodapplication.ui.RestaurantOrdersActivity
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var drawerToggle: ActionBarDrawerToggle
    private lateinit var mainRecyclerView: RecyclerView
    private lateinit var nearbyRecyclerView: RecyclerView
    private val auth = FirebaseAuth.getInstance()
    private val firestore = FirebaseFirestore.getInstance()

    private lateinit var mainFoodItemList: MutableList<FoodItem>
    private lateinit var nearbyFoodItemList: MutableList<FoodItem>
    private lateinit var displayedMainFoodItemList: MutableList<FoodItem>
    private lateinit var displayedNearbyFoodItemList: MutableList<FoodItem>

    private lateinit var mainAdapter: FoodItemAdapter
    private lateinit var nearbyAdapter: NearByFoodAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.statusBarColor = getColor(R.color.app_color)

        setupSearchView()
        setUserProfileInfo()

        val sharedPreferences = getSharedPreferences(Variables.MY_PREF, Context.MODE_PRIVATE)
        val userRole = sharedPreferences.getInt(Variables.USER_ROLE, 0)

        if (userRole == 1) {
            binding.cart.visibility = View.GONE
            binding.myorderds.visibility = View.VISIBLE
        } else if (userRole == 2) {
            binding.fab.visibility = View.GONE
        }


        binding.myorderds.setOnClickListener {
            val intent = Intent(this, AdminOdersList::class.java)
            startActivity(intent)
        }


        drawerToggle = ActionBarDrawerToggle(
            this,
            binding.drawerLayout,
            binding.customToolbar,
            R.string.navigation_drawer_open,
            R.string.navigation_drawer_close
        )

        drawerToggle.drawerArrowDrawable.color = getColor(R.color.white)
        binding.drawerLayout.addDrawerListener(drawerToggle)
        drawerToggle.syncState()

        setupMainRecyclerView()
        fetchFoodItems()

        setupNearbyRecyclerView()
        fetchFoodItems2()

        val headerView = binding.navView.getHeaderView(0)
        val nameTextView: TextView = headerView.findViewById(R.id.nameOfPerson)
        val emailTextView: TextView = headerView.findViewById(R.id.emailOfUser)

        nameTextView.setOnClickListener {
            navigateToAnotherPage()
        }
        emailTextView.setOnClickListener {
            navigateToAnotherPage()
        }

        binding.fab.setOnClickListener {
            val intent = Intent(this, AddFoodItems::class.java)
            startActivity(intent)
        }

        binding.navView.setNavigationItemSelectedListener { menuItem ->
            when (menuItem.itemId) {
                R.id.nav_rate_us -> {
                    openRateUs()
                }

                R.id.orders -> {


                    val intent = if (userRole == 1) Intent(
                        this,
                        RestaurantOrdersActivity::class.java
                    ) else Intent(this, MyOrdersActivity::class.java)
                    startActivity(intent)
                }

                R.id.share -> {
                    shareApp()
                }

                R.id.contactus -> {
                    contactUs()
                }

                R.id.profile -> {
                    val intent = Intent(this, ProfilePage::class.java)
                    startActivity(intent)
                }

                R.id.nav_logout -> {
                    FirebaseAuth.getInstance().signOut()
                    val intent = Intent(this@MainActivity, LoginPage::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                }
            }

            binding.drawerLayout.closeDrawer(GravityCompat.START)
            true
        }

        binding.cart.setOnClickListener {
            val intent = Intent(this, CartActivity::class.java)
            startActivity(intent)
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return if (drawerToggle.onOptionsItemSelected(item)) {
            true
        } else {
            super.onOptionsItemSelected(item)
        }
    }

    private fun setupMainRecyclerView() {
        mainRecyclerView = binding.foodItems
        mainRecyclerView.layoutManager = GridLayoutManager(this, 2)
        mainFoodItemList = mutableListOf()
        displayedMainFoodItemList = mutableListOf()
        mainAdapter = FoodItemAdapter(this, displayedMainFoodItemList)
        mainRecyclerView.adapter = mainAdapter
    }

    private fun setupNearbyRecyclerView() {
        nearbyRecyclerView = binding.nearBY
        nearbyRecyclerView.layoutManager =
            LinearLayoutManager(this, LinearLayoutManager.HORIZONTAL, false)
        nearbyFoodItemList = mutableListOf()
        displayedNearbyFoodItemList = mutableListOf()
        nearbyAdapter = NearByFoodAdapter(displayedNearbyFoodItemList)
        nearbyRecyclerView.adapter = nearbyAdapter
    }

    private fun setupSearchView() {
        binding.searchView.setOnQueryTextListener(object :
            android.widget.SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String?): Boolean {
                filterFoodItems(query ?: "")
                return true
            }

            override fun onQueryTextChange(newText: String?): Boolean {
                filterFoodItems(newText ?: "")
                return true
            }
        })
    }

    private fun setUserProfileInfo() {
        val currentUser = auth.currentUser

        if (currentUser != null) {
            val userId = currentUser.email
            firestore.collection(Variables.COLLECTION_NAME).document(userId!!)
                .get()
                .addOnSuccessListener { document ->
                    if (document != null) {
                        val name = document.getString(Variables.NAME)
                        val email = document.getString(Variables.EMAIl)

                        val headerView = binding.navView.getHeaderView(0)
                        val nameTextView: TextView = headerView.findViewById(R.id.nameOfPerson)
                        val emailTextView: TextView = headerView.findViewById(R.id.emailOfUser)

                        nameTextView.text = name ?: Variables.USER
                        emailTextView.text = email ?: currentUser.email
                    }
                }
                .addOnFailureListener {
                    Constant.showToast(this, Variables.FAIL_TO_LOAD)
                }
        }
    }

    private fun fetchFoodItems2() {

        val sharedPreferences = getSharedPreferences(Variables.MY_PREF, Context.MODE_PRIVATE)
        val userPlace = sharedPreferences.getString(Variables.PLACE_F, "")


        firestore.collection(Variables.FOOD_ITEM)
            .whereEqualTo(Variables.ENTER_FOOD_PLACE, userPlace)
            .get()
            .addOnSuccessListener { querySnapshot ->
                nearbyFoodItemList.clear()
                for (document in querySnapshot.documents) {
                    val foodItem = document.toObject(FoodItem::class.java)
                    if (foodItem != null) {
                        nearbyFoodItemList.add(foodItem)
                    }
                }
                displayedNearbyFoodItemList.clear()
                displayedNearbyFoodItemList.addAll(nearbyFoodItemList)
                nearbyAdapter.notifyDataSetChanged()
            }
            .addOnFailureListener { exception ->
            }
    }

    private fun fetchFoodItems() {
        binding.progressBar.visibility = View.VISIBLE
        binding.foodItems.visibility = View.GONE
        firestore.collection(Variables.FOOD_ITEM).get()
            .addOnSuccessListener { documents ->
                mainFoodItemList.clear()
                displayedMainFoodItemList.clear()
                for (document in documents) {
                    val foodItem = FoodItem(
                        foodName = document.getString(Variables.ENTER_FOOD_NAME)!!,
                        foodQuantity = document.getString(Variables.ENTER_FOOD_QUANTITY)!!,
                        imageUrl = document.getString(Variables.IMAGE_URL)!!,
                        foodPlace = document.getString(Variables.FF_PP)!!,
                        foodAmount = document.getString(Variables.FF_AA)!!,
                        foodId = document.getString((Variables.FOOD_ID))!!,
                        foodCity = document.getString(Variables.FF_CC)!!,
                        restaurantId = document.getString(Variables.RESTURENT_Id)!!
                    )
                    mainFoodItemList.add(foodItem)
                }
                displayedMainFoodItemList.addAll(mainFoodItemList)
                binding.progressBar.visibility = View.GONE
                binding.foodItems.visibility = View.VISIBLE
                mainAdapter.notifyDataSetChanged()
            }
            .addOnFailureListener {
                Constant.showToast(this, Variables.FAILED_TO_LOAD_ITEMS)
                binding.progressBar.visibility = View.GONE
                binding.foodItems.visibility = View.VISIBLE
            }
    }

    private fun filterFoodItems(query: String) {
        displayedMainFoodItemList.clear()
        if (query.isEmpty()) {
            displayedMainFoodItemList.addAll(mainFoodItemList)
        } else {
            displayedMainFoodItemList.addAll(mainFoodItemList.filter {
                it.foodName.contains(
                    query,
                    ignoreCase = true
                )
            })
        }
        mainAdapter.notifyDataSetChanged()
    }


    private fun openRateUs() {
        try {
            val uri = Uri.parse(Variables.LINK + packageName)
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        } catch (e: ActivityNotFoundException) {
            val uri = Uri.parse(Variables.LINK2 + packageName)
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            startActivity(intent)
        }
    }

    private fun shareApp() {
        val shareText = Variables.FORMAL_TEXT + packageName
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = Variables.TYPE1
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        startActivity(Intent.createChooser(intent, Variables.SHARE_VIA))
    }

    private fun contactUs() {
        val emailIntent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse(Variables.MAILTO)
            putExtra(Intent.EXTRA_EMAIL, arrayOf(Variables.CUSTOM_EMAIL))
            putExtra(Intent.EXTRA_SUBJECT, Variables.SUPPORT)
        }
        try {
            startActivity(Intent.createChooser(emailIntent, Variables.VIA))
        } catch (e: ActivityNotFoundException) {
            Constant.showToast(this, Variables.NO_EMAIL)
        }
    }

    private fun navigateToAnotherPage() {
        val intent = Intent(this, ProfilePage::class.java)
        startActivity(intent)
    }
}