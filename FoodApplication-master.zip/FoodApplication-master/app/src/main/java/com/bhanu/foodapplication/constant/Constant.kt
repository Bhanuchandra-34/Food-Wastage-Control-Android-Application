package com.bhanu.foodapplication.constant

import android.app.Dialog
import android.content.Context
import android.view.Window
import android.widget.Toast
import com.bhanu.foodapplication.R

class Constant {

    companion object {
        private var loadingDialog: Dialog? = null

        fun showToast(context: Context, message: String) {
            Toast.makeText(context, message, Toast.LENGTH_SHORT).show()
        }

        fun showLoadingDialog(context: Context) {
            loadingDialog = Dialog(context).apply {
                requestWindowFeature(Window.FEATURE_NO_TITLE)
                setCancelable(false)
                setContentView(R.layout.custom_dialog)
                window?.setBackgroundDrawableResource(android.R.color.transparent)
            }

            loadingDialog?.show()
        }

        fun dismissLoadingDialog() {
            loadingDialog?.dismiss()
        }

    }

}