package com.bhanu.foodapplication.ui

import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.bhanu.foodapplication.MainActivity
import com.bhanu.foodapplication.R
import com.bhanu.foodapplication.adapter.CartAdapter
import com.bhanu.foodapplication.constant.Constant
import com.bhanu.foodapplication.constant.Variables
import com.bhanu.foodapplication.databinding.ActivityCartBinding
import com.bhanu.foodapplication.room.FoodDatabase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.UUID

class CartActivity : AppCompatActivity() {

    private lateinit var binding: ActivityCartBinding
    private lateinit var cartAdapter: CartAdapter

    private lateinit var firestore: FirebaseFirestore
    private lateinit var auth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityCartBinding.inflate(layoutInflater)
        setContentView(binding.root)
        window.statusBarColor = getColor(R.color.app_color)

        binding.progressBar.visibility = View.VISIBLE
        binding.addToCartRv.visibility = View.GONE
        binding.addToCartRv.layoutManager = LinearLayoutManager(this)
        firestore = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        val userEmail = auth.currentUser?.email

        if (userEmail != null) {
            fetchUserData(userEmail)
        }
        
        binding.back3.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        binding.checkout.setOnClickListener {
            lifecycleScope.launch {
                val foodDao = FoodDatabase.getDatabase(applicationContext).foodDao()
                val foodList = foodDao.getAllFood().toMutableList() // Retrieve all cart items

                if (foodList.isEmpty()) {
                    Constant.showToast(this@CartActivity, Variables.CART_EMPTY)
                    return@launch
                }

                val orderId = UUID.randomUUID().toString() 
                val userEmail = auth.currentUser?.email
                val orderData = hashMapOf(
                    Variables.ORDER_ID to orderId,
                    Variables.ORDER_USER_EMAIL to userEmail,
                    Variables.ORDER_ITEMS to foodList.map { food ->
                        mapOf(
                            Variables.FF_NN to food.foodName,
                            Variables.FF_QQ to food.foodQuantity,
                            Variables.FF_CC to food.foodCity,
                            Variables.FF_PP to food.foodPlace,
                            Variables.FF_AA to food.foodAmount,
                            Variables.FF_IMG_URL to food.imageUrl,
                            Variables.FF_EE to food.restaurantId
                        )
                    },
                    Variables.ORDER_TIMESTAMP to System.currentTimeMillis()
                )

                firestore.collection(Variables.ORDER_COLLECTION).document(orderId)
                    .set(orderData)
                    .addOnSuccessListener {
                        lifecycleScope.launch {
                            // Clear the cart after successful order
                            foodDao.clearCart()
                            withContext(Dispatchers.Main) {
                                Constant.showToast(this@CartActivity, Variables.ORDER_SUCCESS)
                                foodList.clear() // Clear the in-memory list
                                cartAdapter.notifyDataSetChanged() // Refresh the adapter
                                finish()
                                
                            }
                        }
                    }
                    .addOnFailureListener { e ->
                        Constant.showToast(this@CartActivity, Variables.ORDER_FAILED)
                    }
            }
        }


        lifecycleScope.launch {
            val foodDao = FoodDatabase.getDatabase(applicationContext).foodDao()
            val foodList = foodDao.getAllFood().toMutableList()

            cartAdapter = CartAdapter(
                foodList = foodList,
                onItemClick = { food ->
                    val intent = Intent(this@CartActivity, FoodDetailActivity::class.java)
                    intent.putExtra(Variables.FF_NN, food.foodName)
                    intent.putExtra(Variables.FF_QQ, food.foodQuantity)
                    intent.putExtra(Variables.FF_CC, food.foodCity)
                    intent.putExtra(Variables.FF_PP, food.foodPlace)
                    intent.putExtra(Variables.FF_AA, food.foodAmount)
                    intent.putExtra(Variables.FF_IMG_URL, food.imageUrl)
                    intent.putExtra(Variables.FF_EE, food.restaurantId)
                    intent.putExtra(Variables.TYPE_CART, Variables.CART)
                    startActivity(intent)
                },
                onDeleteClick = { food ->
                    lifecycleScope.launch {
                        foodDao.deleteFood(food)
                        withContext(Dispatchers.Main) {
                            foodList.remove(food)
                            cartAdapter.notifyDataSetChanged()
                        }
                    }
                }
            )

            binding.addToCartRv.adapter = cartAdapter
            binding.progressBar.visibility = View.GONE
            binding.addToCartRv.visibility = View.VISIBLE
        }
    }

    private fun fetchUserData(email: String) {
        firestore.collection(Variables.USERS).document(email).get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    val name = document.getString(Variables.USER_PROFILE_NAME)!!
                    val userEmail = document.getString(Variables.USER_PROFILE_EMAIl)!!
                    val city = document.getString(Variables.USER_PROFILE_CITY)!!
                    val place = document.getString(Variables.USER_PROFILE_PLACE)!!

                    binding.reciverName.text = name
                    binding.email.text = userEmail
                    binding.dilverAddreess.text = "$place,$city"
                } else {
                    Constant.showToast(this, Variables.USER_NOT_FOUND)
                }
            }
            .addOnFailureListener { e ->
                Constant.showToast(this, Variables.USER_NOT_FOUND_FAILED)
            }
    }
}
