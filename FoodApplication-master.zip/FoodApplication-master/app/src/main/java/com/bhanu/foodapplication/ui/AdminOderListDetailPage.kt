package com.bhanu.foodapplication.ui

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.bhanu.foodapplication.R
import com.bhanu.foodapplication.constant.Variables
import com.bhanu.foodapplication.databinding.ActivityAdminOderListDetailPageBinding
import com.bumptech.glide.Glide

class AdminOderListDetailPage : AppCompatActivity() {

    private lateinit var binding: ActivityAdminOderListDetailPageBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityAdminOderListDetailPageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = getColor(R.color.app_color)


        val name= intent.getStringExtra(Variables.FF_NN)
        val quantity= intent.getStringExtra(Variables.FF_QQ)
        val city= intent.getStringExtra(Variables.FF_CC)
        val place= intent.getStringExtra(Variables.FF_PP)
        val documentId= intent.getStringExtra(Variables.FOOD_ID)
        val imageUrl= intent.getStringExtra(Variables.FF_IMG_URL)
        val amount= intent.getStringExtra(Variables.FF_AA)


        if (amount == "") {
            binding.amount.visibility = View.GONE
        } else {
            binding.amount.visibility = View.VISIBLE
            binding.foodAmount.text = amount
        }

        binding.foodName.text=name
        binding.foodQuant.text=quantity
        binding.foodCity.text=city
        binding.foodPla.text=place
        if (!imageUrl.isNullOrEmpty()) {
            Glide.with(this)
                .load(imageUrl)
                .into(binding.foodImage)
        }

    }
}