package com.bhanu.foodapplication.ui


import MyOrderAdapter
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.bhanu.foodapplication.databinding.ActivityMyOrdersBinding
import com.bhanu.foodapplication.model.MyOrderItem
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class MyOrdersActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMyOrdersBinding
    private lateinit var firestore: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var adapter: MyOrderAdapter
    private val items = mutableListOf<MyOrderItem>() // A flat list for orders and their items

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMyOrdersBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firestore = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        binding.ordersRecyclerView.layoutManager = LinearLayoutManager(this)

        adapter = MyOrderAdapter(items) { clickedItem ->
            if (clickedItem.isHeader) {
                Toast.makeText(this, "Clicked on Order ID: ${clickedItem.orderId}", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Clicked on Food: ${clickedItem.foodName}", Toast.LENGTH_SHORT).show()
            }
        }
        binding.ordersRecyclerView.adapter = adapter

        fetchOrders()
    }

    private fun fetchOrders() {
        val userEmail = auth.currentUser?.email
        if (userEmail != null) {
            firestore.collection("orders")
                .whereEqualTo("user_email", userEmail)
                .get()
                .addOnSuccessListener { documents ->
                    items.clear()
                    for (document in documents) {
                        val orderId = document.getString("order_id") ?: ""
                        val orderTimestamp = document.getLong("order_timestamp") ?: 0L
                        val orderItemsList =
                            document.get("order_items") as? List<Map<String, Any>> ?: emptyList()

                        // Add a header for the order
                        items.add(
                            MyOrderItem(
                                isHeader = true,
                                orderId = orderId,
                                orderTimestamp = orderTimestamp
                            )
                        )

                        // Add all items in the order
                        orderItemsList.forEach { item ->
                            items.add(
                                MyOrderItem(
                                    isHeader = false,
                                    foodAmount = item["foodAmount"] as? String ?: "",
                                    foodCity = item["foodCity"] as? String ?: "",
                                    foodName = item["foodName"] as? String ?: "",
                                    foodPlace = item["foodPlace"] as? String ?: "",
                                    foodQuantity = item["foodQuantity"] as? String ?: "",
                                    imageUrl = item["imageUrl"] as? String ?: "",
                                    restaurantId = item["restaurantId"] as? String ?: ""
                                )
                            )
                        }
                    }
                    adapter.notifyDataSetChanged()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Failed to fetch orders: ${e.message}", Toast.LENGTH_SHORT)
                        .show()
                }
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
        }
    }
}
