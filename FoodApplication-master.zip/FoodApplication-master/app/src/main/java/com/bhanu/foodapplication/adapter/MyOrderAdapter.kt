import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.bhanu.foodapplication.R
import com.bhanu.foodapplication.model.MyOrderItem
import com.bumptech.glide.Glide
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MyOrderAdapter(
    private val items: List<MyOrderItem>,
    private val onClick: (MyOrderItem) -> Unit
) : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val VIEW_TYPE_HEADER = 0
        private const val VIEW_TYPE_ITEM = 1
    }

    override fun getItemViewType(position: Int): Int {
        return if (items[position].isHeader) VIEW_TYPE_HEADER else VIEW_TYPE_ITEM
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return if (viewType == VIEW_TYPE_HEADER) {
            val view = LayoutInflater.from(parent.context)
                .inflate(R.layout.item_order_header, parent, false)
            OrderHeaderViewHolder(view)
        } else {
            val view =
                LayoutInflater.from(parent.context).inflate(R.layout.item_my_orders, parent, false)
            OrderItemViewHolder(view)
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val item = items[position]
        if (holder is OrderHeaderViewHolder) {
            holder.bind(item, onClick)
        } else if (holder is OrderItemViewHolder) {
            holder.bind(item, onClick)
        }
    }


    override fun getItemCount(): Int = items.size

    class OrderHeaderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val orderIdTextView: TextView = itemView.findViewById(R.id.orderIdTextView)
        private val orderTimestampTextView: TextView =
            itemView.findViewById(R.id.orderTimestampTextView)

        fun bind(item: MyOrderItem, onClick: (MyOrderItem) -> Unit) {
            orderIdTextView.text = "Order ID: ${item.orderId}"
            orderTimestampTextView.text =
                "Timestamp: ${convertTimestampToDate(item.orderTimestamp)}"
            itemView.setOnClickListener { onClick(item) }
        }
        private fun convertTimestampToDate(timestamp: Long): String {
            val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault())
            return sdf.format(Date(timestamp))
        }
    }

    class OrderItemViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val foodNameTextView: TextView = itemView.findViewById(R.id.foodNameTextView)
        private val foodQuantityTextView: TextView =
            itemView.findViewById(R.id.foodQuantityTextView)
        private val foodImageView: ImageView = itemView.findViewById(R.id.foodImageView)

        fun bind(item: MyOrderItem, onClick: (MyOrderItem) -> Unit) {
            foodNameTextView.text = item.foodName
            foodQuantityTextView.text = "Quantity: ${item.foodQuantity}"
            Glide.with(itemView.context).load(item.imageUrl).into(foodImageView)
            itemView.setOnClickListener { onClick(item) }
        }
    }

  
}
