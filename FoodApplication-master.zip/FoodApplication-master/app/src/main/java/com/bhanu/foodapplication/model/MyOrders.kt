package com.bhanu.foodapplication.model

data class MyOrder(
    val orderId: String = "",
    val orderTimestamp: Long = 0L,
    val userEmail: String = "",
    val orderItems: List<OrderItem> = emptyList()
) {
    data class OrderItem(
        val foodAmount: String = "",
        val foodCity: String = "",
        val foodName: String = "",
        val foodPlace: String = "",
        val foodQuantity: String = "",
        val imageUrl: String = "",
        val restaurantId: String = ""
    )
}

data class MyOrderItem(
    val isHeader: Boolean,
    val orderId: String = "",
    val orderTimestamp: Long = 0L,
    val foodAmount: String = "",
    val foodCity: String = "",
    val foodName: String = "",
    val foodPlace: String = "",
    val foodQuantity: String = "",
    val imageUrl: String = "",
    val restaurantId: String = ""
)
