package com.bhanu.foodapplication.api

import com.bhanu.foodapplication.constant.Variables
import com.bhanu.foodapplication.model.NotificationResponse
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part

interface ApiInterface {
    @Multipart
    @POST(Variables.END_POINT)
    fun sendNotification(
        @Part(Variables.PROJECT_NAME) projectName :RequestBody,
        @Part(Variables.TITLE) title :RequestBody,
        @Part(Variables.MESSAGE) message :RequestBody,
        @Part(Variables.TOPI) topic :RequestBody,
    ): Call<NotificationResponse>
}