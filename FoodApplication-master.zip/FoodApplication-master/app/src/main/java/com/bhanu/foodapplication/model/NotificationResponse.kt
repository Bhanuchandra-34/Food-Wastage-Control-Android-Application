package com.bhanu.foodapplication.model

data class NotificationResponse(
    val success:Boolean,
    val msg:String
)
