package com.bhanu.foodapplication.model

data class Order(
    val documentId: String = "",
    val foodName: String = "",
    val foodCity: String = "",
    val foodPlace: String = "",
    val foodQuantity: String = "",
    val foodAmount: String = "",
    val imageUrl: String = ""
)
