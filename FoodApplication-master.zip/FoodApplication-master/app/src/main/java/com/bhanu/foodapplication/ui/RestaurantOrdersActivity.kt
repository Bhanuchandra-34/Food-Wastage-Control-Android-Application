package com.bhanu.foodapplication.ui

import android.os.Bundle
import android.widget.Toast
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.recyclerview.widget.LinearLayoutManager
import com.bhanu.foodapplication.R
import com.bhanu.foodapplication.adapter.RestaurantOrderAdapter
import com.bhanu.foodapplication.adapter.RestaurantOrderItem
import com.bhanu.foodapplication.databinding.ActivityRestaurantOrdersBinding
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

class RestaurantOrdersActivity : AppCompatActivity() {
    private lateinit var binding: ActivityRestaurantOrdersBinding
    private lateinit var firestore: FirebaseFirestore
    private lateinit var auth: FirebaseAuth
    private lateinit var adapter: RestaurantOrderAdapter
    private val items = mutableListOf<RestaurantOrderItem>() // Flat list for orders and items

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRestaurantOrdersBinding.inflate(layoutInflater)
        setContentView(binding.root)

        firestore = FirebaseFirestore.getInstance()
        auth = FirebaseAuth.getInstance()

        binding.ordersRecyclerView.layoutManager = LinearLayoutManager(this)

        adapter = RestaurantOrderAdapter(items) { clickedItem ->
            if (clickedItem.isHeader) {
                Toast.makeText(this, "Clicked on Order ID: ${clickedItem.orderId}", Toast.LENGTH_SHORT).show()
            } else {
                Toast.makeText(this, "Clicked on Food: ${clickedItem.foodName}", Toast.LENGTH_SHORT).show()
            }
        }
        binding.ordersRecyclerView.adapter = adapter

        fetchRestaurantOrders()
    }

    private fun fetchRestaurantOrders() {
        val restaurantEmail = auth.currentUser?.email // Get logged-in restaurant owner's email
        if (restaurantEmail != null) {
            firestore.collection("orders")
                .get()
                .addOnSuccessListener { documents ->
                    items.clear()
                    for (document in documents) {
                        val orderId = document.getString("order_id") ?: ""
                        val orderTimestamp = document.getLong("order_timestamp") ?: 0L
                        val orderItemsList =
                            document.get("order_items") as? List<Map<String, Any>> ?: emptyList()

                        // Filter items by restaurant email
                        val restaurantItems = orderItemsList.filter { item ->
                            item["restaurantId"] == restaurantEmail
                        }

                        // Only add orders that have items for this restaurant
                        if (restaurantItems.isNotEmpty()) {
                            // Add a header for the order
                            items.add(
                                RestaurantOrderItem(
                                    isHeader = true,
                                    orderId = orderId,
                                    orderTimestamp = orderTimestamp
                                )
                            )

                            // Add all items belonging to the restaurant
                            restaurantItems.forEach { item ->
                                items.add(
                                    RestaurantOrderItem(
                                        isHeader = false,
                                        foodAmount = item["foodAmount"] as? String ?: "",
                                        foodCity = item["foodCity"] as? String ?: "",
                                        foodName = item["foodName"] as? String ?: "",
                                        foodPlace = item["foodPlace"] as? String ?: "",
                                        foodQuantity = item["foodQuantity"] as? String ?: "",
                                        imageUrl = item["imageUrl"] as? String ?: "",
                                        restaurantId = item["restaurantId"] as? String ?: ""
                                    )
                                )
                            }
                        }
                    }
                    adapter.notifyDataSetChanged()
                }
                .addOnFailureListener { e ->
                    Toast.makeText(this, "Failed to fetch orders: ${e.message}", Toast.LENGTH_SHORT)
                        .show()
                }
        } else {
            Toast.makeText(this, "User not logged in", Toast.LENGTH_SHORT).show()
        }
    }
}