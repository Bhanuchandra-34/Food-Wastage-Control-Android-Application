package com.bhanu.foodapplication.adapter

import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.bhanu.foodapplication.constant.Variables
import com.bhanu.foodapplication.databinding.NearByItemsBinding
import com.bhanu.foodapplication.model.FoodItem
import com.bhanu.foodapplication.ui.FoodDetailActivity
import com.bumptech.glide.Glide

class NearByFoodAdapter(private val foodItems: List<FoodItem>) : RecyclerView.Adapter<NearByFoodAdapter.FoodViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): FoodViewHolder {
        val binding = NearByItemsBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return FoodViewHolder(binding)
    }

    override fun onBindViewHolder(holder: FoodViewHolder, position: Int) {
        holder.bind(foodItems[position])
    }

    override fun getItemCount() = foodItems.size

    inner class FoodViewHolder(private val binding: NearByItemsBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(foodItem: FoodItem) {
            binding.tvAddress.text = foodItem.foodName
            binding.quantity.text = foodItem.foodQuantity

            Glide.with(binding.root.context)
                .load(foodItem.imageUrl)
                .into(binding.img)

            itemView.setOnClickListener {
                val context = itemView.context
                val intent=Intent(context,FoodDetailActivity::class.java)
                intent.putExtra(Variables.FF_NN,foodItem.foodName)
                intent.putExtra(Variables.FF_QQ,foodItem.foodQuantity)
                intent.putExtra(Variables.FF_CC, foodItem.foodCity)
                intent.putExtra(Variables.FF_PP,foodItem.foodPlace)
                intent.putExtra(Variables.FF_IMG_URL, foodItem.imageUrl)
                intent.putExtra(Variables.FF_AA,foodItem.foodAmount)
                intent.putExtra(Variables.RESTURENT_Id,foodItem.restaurantId)
                context.startActivity(intent)
            }

        }
    }
}
