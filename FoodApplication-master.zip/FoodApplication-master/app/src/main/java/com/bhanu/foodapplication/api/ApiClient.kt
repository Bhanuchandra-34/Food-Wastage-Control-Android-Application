package com.bhanu.foodapplication.api

import com.bhanu.foodapplication.constant.Variables
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object ApiClient {

    private var retrofit: Retrofit ?= null


    public fun getApiInterface():Retrofit{
        if (retrofit == null){
            retrofit= Retrofit.Builder()
                .baseUrl(Variables.BASE_URL)
                .addConverterFactory(GsonConverterFactory.create())
                .build()
        }
       return retrofit!!
    }

}