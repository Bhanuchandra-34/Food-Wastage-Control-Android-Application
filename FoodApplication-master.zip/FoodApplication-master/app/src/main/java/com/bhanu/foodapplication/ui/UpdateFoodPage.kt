package com.bhanu.foodapplication.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import com.bhanu.foodapplication.R
import com.bhanu.foodapplication.constant.Constant
import com.bhanu.foodapplication.constant.Variables
import com.bhanu.foodapplication.databinding.ActivityUpdateFoodPageBinding
import com.bumptech.glide.Glide
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.storage.FirebaseStorage

class UpdateFoodPage : AppCompatActivity() {

    private lateinit var binding:ActivityUpdateFoodPageBinding
    private var imageUri: Uri? = null
    private val PICK_IMAGE_REQUEST = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding=ActivityUpdateFoodPageBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = getColor(R.color.app_color)

        val fName = intent.getStringExtra(Variables.FF_NN)
        val qName = intent.getStringExtra(Variables.FF_QQ)
        val cName = intent.getStringExtra(Variables.FF_CC)
        val pName = intent.getStringExtra(Variables.FF_PP)
        val foodId=intent.getStringExtra(Variables.FOOD_ID)
        val iUrl = intent.getStringExtra(Variables.FF_IMG_URL)
        val amount = intent.getStringExtra(Variables.FF_AA)

        binding.foodName.setText(fName)
        binding.enterQuantity.setText(qName)
        binding.enterAmount.setText(amount)
        binding.enterCity.setText(cName)
        binding.enterPlace.setText(pName)


        if (!iUrl.isNullOrEmpty()) {
            binding.foodImage.visibility = View.VISIBLE
            Glide.with(this)
                .load(iUrl)
                .into(binding.foodImage)
        }

        binding.addItem.setOnClickListener {
            if (validateData()) {
                updateData()
            }

        }
        binding.openGallery.setOnClickListener { openGallery() }
    }
    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = Variables.UPLOAD_TYPE
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            imageUri = data.data
            binding.foodImage.visibility = View.VISIBLE
            binding.foodImage.setImageURI(imageUri)
        }
    }

    private fun validateData(): Boolean {
        val foodName = binding.foodName.text.toString().trim()
        val foodQuantity = binding.enterQuantity.text.toString().trim()
        val foodCity = binding.enterCity.text.toString().trim()
        val foodPlace = binding.enterPlace.text.toString().trim()

        if (foodName.isEmpty()) {
            Constant.showToast(this, Variables.FOOD_NAME)
            return false
        }
        if (foodQuantity.isEmpty()) {
            Constant.showToast(this, Variables.ENTER_QUANTITY)
            return false
        }
        if (foodCity.isEmpty()) {
            Constant.showToast(this, Variables.ENTER_CITY)
            return false
        }
        if (foodPlace.isEmpty()) {
            Constant.showToast(this, Variables.ENTER_PLACE)
            return false
        }
        return true
    }

    private fun updateData() {
        Constant.showLoadingDialog(this)

        val updatedData = mutableMapOf<String, Any>()
        val foodName = binding.foodName.text.toString().trim()
        val foodQuantity = binding.enterQuantity.text.toString().trim()
        val foodCity = binding.enterCity.text.toString().trim()
        val foodPlace = binding.enterPlace.text.toString().trim()
        val foodAmount = binding.enterAmount.text.toString().trim()

        if (foodName != intent.getStringExtra(Variables.FF_NN)) {
            updatedData[Variables.ENTER_FOOD_NAME] = foodName
        }
        if (foodQuantity != intent.getStringExtra(Variables.FF_QQ)) {
            updatedData[Variables.ENTER_FOOD_QUANTITY] = foodQuantity
        }
        if (foodCity != intent.getStringExtra(Variables.FF_CC)) {
            updatedData[Variables.ENTER_FOOD_CITY] = foodCity
        }
        if (foodPlace != intent.getStringExtra(Variables.FF_PP)) {
            updatedData[Variables.ENTER_FOOD_PLACE] = foodPlace
        }
        if (foodAmount != intent.getStringExtra(Variables.FF_AA)) {
            updatedData[Variables.ENTER_PRICE] = foodAmount
        }

        if (imageUri != null) {
            val storageReference = FirebaseStorage.getInstance().reference.child(Variables.FOOD_IMAGES)
            storageReference.putFile(imageUri!!)
                .addOnSuccessListener {
                    storageReference.downloadUrl.addOnSuccessListener { downloadUri ->
                        updatedData[Variables.IMAGE_URL] = downloadUri.toString()
                        saveUpdatesToFirestore(updatedData)
                    }
                }
                .addOnFailureListener {
                    Constant.showToast(this, Variables.FAILED_TO_UPLOAD_FOOD_IMAGES)
                    Constant.dismissLoadingDialog()
                }
        } else {
            saveUpdatesToFirestore(updatedData)
        }
    }

    private fun saveUpdatesToFirestore(updatedData: Map<String, Any>) {
        val foodId=intent.getStringExtra(Variables.FOOD_ID)

        if (foodId.isNullOrEmpty()) return

        val db = FirebaseFirestore.getInstance()
        db.collection(Variables.FOOD_ITEM)
            .document(foodId!!)
            .set(updatedData, SetOptions.merge())
            .addOnSuccessListener {
                Constant.dismissLoadingDialog()
                Constant.showToast(this, Variables.FOOD_UPDATED_TOAST)
                finish()
            }
            .addOnFailureListener {
                Constant.dismissLoadingDialog()
                Constant.showToast(this, Variables.FOOD_NOT_UPDATED_TOAST)
            }
    }
}