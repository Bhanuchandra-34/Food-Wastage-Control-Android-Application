package com.bhanu.foodapplication.ui

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.bhanu.foodapplication.MainActivity
import com.bhanu.foodapplication.R
import com.bhanu.foodapplication.api.ApiClient
import com.bhanu.foodapplication.api.ApiInterface
import com.bhanu.foodapplication.constant.Constant
import com.bhanu.foodapplication.constant.Variables
import com.bhanu.foodapplication.databinding.ActivityAddFoodItemsBinding
import com.bhanu.foodapplication.model.NotificationResponse
import com.bumptech.glide.Glide
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import com.google.firebase.messaging.FirebaseMessaging
import com.google.firebase.storage.FirebaseStorage
import okhttp3.MediaType
import okhttp3.RequestBody
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AddFoodItems : AppCompatActivity() {

    private lateinit var binding: ActivityAddFoodItemsBinding
    private var imageUri: Uri? = null
    private val PICK_IMAGE_REQUEST = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityAddFoodItemsBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = getColor(R.color.app_color)
        ui()

        FirebaseMessaging.getInstance().subscribeToTopic(Variables.TOPIC)


    }

    private fun ui() {
        binding.addItem.setOnClickListener {
            if (validateData()) {
                uploadData()
            }
        }

        binding.openGallery.setOnClickListener {
            openGallery()
        }

        binding.back4.setOnClickListener {
            val intent=Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK)
        intent.type = Variables.UPLOAD_TYPE
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == PICK_IMAGE_REQUEST && resultCode == Activity.RESULT_OK && data != null && data.data != null) {
            imageUri = data.data
            binding.foodImage.visibility=View.VISIBLE
            binding.foodImage.setImageURI(imageUri)
        }
    }

    private fun validateData(): Boolean {
        val foodName = binding.foodName.text.toString().trim()
        val foodQuantity =binding.enterQuantity.text.toString().trim()
        val foodCity =binding.enterCity.text.toString().trim()
        val foodPlace=binding.enterPlace.text.toString().trim()


        if (foodName.isEmpty()) {
            Constant.showToast(this, Variables.FOOD_NAME)
            return false
        }
        if (foodQuantity.isEmpty()) {
            Constant.showToast(this, Variables.ENTER_QUANTITY )
            return false
        }
        if (foodCity.isEmpty()){
            Constant.showToast(this, Variables.ENTER_CITY )
            return false
        }
        if (foodPlace.isEmpty()){
            Constant.showToast(this, Variables.ENTER_PLACE )
            return false
        }
        if (imageUri == null) {
            Constant.showToast(this, Variables.UPLOAD_FOOD_IMAGE)
            return false
        }
        return true
    }

    private fun uploadData() {
        Constant.showLoadingDialog(this)
        val foodName = binding.foodName.text.toString().trim()
        val foodQuantity = binding.enterQuantity.text.toString().trim()
        val foodCity = binding.enterCity.text.toString().trim()
        val foodPlace = binding.enterPlace.text.toString().trim()
        val foodAmount=binding.enterAmount.text.toString().trim()


        val storageReference = FirebaseStorage.getInstance().reference.child(Variables.FOOD_IMAGES)

        imageUri?.let { uri ->
            storageReference.putFile(uri)
                .addOnSuccessListener {
                    storageReference.downloadUrl.addOnSuccessListener { downloadUri ->
                        saveDataToFirestore(foodName, foodQuantity, foodCity, foodPlace,foodAmount, downloadUri.toString())
                    }
                }
                .addOnFailureListener { e->
                    Constant.dismissLoadingDialog()
                    Constant.showToast(this, Variables.FAILED_TO_UPLOAD_FOOD_IMAGES)
                }
        }
    }

    private fun saveDataToFirestore(foodName: String, foodQuantity: String, foodCity: String, foodPlace: String,foodAmount:String, imageUrl: String) {
        val db = FirebaseFirestore.getInstance()
        val documentRef = db.collection(Variables.FOOD_ITEM).document()

        val currentUser = FirebaseAuth.getInstance().currentUser
        val restaurantId = currentUser?.email

        val foodData = hashMapOf(
            Variables.ENTER_FOOD_NAME to foodName,
            Variables.ENTER_FOOD_QUANTITY to foodQuantity,
            Variables.ENTER_FOOD_CITY to foodCity,
            Variables.ENTER_FOOD_PLACE to foodPlace,
            Variables.ENTER_PRICE to foodAmount,
            Variables.IMAGE_URL to imageUrl,
            Variables.FOOD_ID to documentRef.id,
            Variables.RESTURENT_Id to restaurantId


        )
        documentRef
            .set(foodData, SetOptions.merge())
            .addOnSuccessListener {
                Constant.dismissLoadingDialog()
                Constant.showToast(this, Variables.FOOD_UPLOADED_TOAST)
                clearFields()
                sendNotify(foodName,foodQuantity)
            }
            .addOnFailureListener {
                Constant.dismissLoadingDialog()
                Constant.showToast(this, Variables.FOOD_NOT_UPLOADED_TOAST)
            }
    }

    private fun clearFields() {
        binding.foodName.text!!.clear()
        binding.enterQuantity.text!!.clear()
        binding.enterCity.text!!.clear()
        binding.enterPlace.text!!.clear()
        binding.enterAmount.text!!.clear()
        binding.foodImage.setImageURI(null)
        binding.foodImage.visibility = View.GONE
        imageUri = null
    }

    fun sendNotify(foodName: String,foodPlace: String){
        ApiClient.getApiInterface().create(ApiInterface::class.java)
            .sendNotification(
                createPartData(Variables.PROJECT_ID),
                createPartData(foodName),
                createPartData(foodPlace),
                createPartData(Variables.TOPIC),
            ).enqueue(object :Callback<NotificationResponse> {
                override fun onResponse(
                    call: Call<NotificationResponse>,
                    response: Response<NotificationResponse>
                ) {
                    if (response.isSuccessful){
                        Constant.showToast(this@AddFoodItems,"Sucess:${response.body()!!.msg}")
                    }else{
                        Constant.showToast(this@AddFoodItems,"Failed")
                    }
                }
                override fun onFailure(call: Call<NotificationResponse>, t: Throwable) {
                    Constant.showToast(this@AddFoodItems,"Error : ${t.message}")
                }
            })
    }

    fun createPartData(value:String) :RequestBody{
        return RequestBody.create(MediaType.parse(Variables.PLAIN), value)
    }
}