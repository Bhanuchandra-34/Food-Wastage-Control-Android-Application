package com.bhanu.foodapplication.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.bhanu.foodapplication.MainActivity
import com.bhanu.foodapplication.R
import com.bhanu.foodapplication.constant.Constant
import com.bhanu.foodapplication.constant.Variables
import com.bhanu.foodapplication.databinding.ActivityFoodDetailBinding
import com.bhanu.foodapplication.model.FoodItem
import com.bhanu.foodapplication.room.FoodDao
import com.bhanu.foodapplication.room.FoodDatabase
import com.bumptech.glide.Glide
import com.google.firebase.firestore.FirebaseFirestore
import kotlinx.coroutines.launch
import java.util.UUID

class FoodDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityFoodDetailBinding
    private lateinit var foodDao: FoodDao
    
    private lateinit var fName : String
    private lateinit var qName : String
    private lateinit var cName : String
    private lateinit var pName : String
    private lateinit var iUrl : String
    private lateinit var type : String
    private lateinit var amount : String
    private lateinit var foodId : String
    private lateinit var restaurantId : String
    

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFoodDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        window.statusBarColor = getColor(R.color.app_color)

         fName = intent.getStringExtra(Variables.FF_NN).toString()
         qName = intent.getStringExtra(Variables.FF_QQ).toString()
         cName = intent.getStringExtra(Variables.FF_CC).toString()
         pName = intent.getStringExtra(Variables.FF_PP).toString()
         iUrl = intent.getStringExtra(Variables.FF_IMG_URL).toString()
         type = intent.getStringExtra(Variables.TYPE_CART).toString()
         amount = intent.getStringExtra(Variables.FF_AA).toString()
         foodId = intent.getStringExtra(Variables.FF_ID).toString()
         restaurantId = intent.getStringExtra(Variables.FF_EE).toString()

        if (amount == "") {
            binding.amount.visibility = View.GONE
        } else {
            binding.amount.visibility = View.VISIBLE
            binding.foodAmount.text = amount
        }
        
        

        foodDao = FoodDatabase.getDatabase(applicationContext).foodDao()
        updateBtn()

        val sharedPreferences = getSharedPreferences(Variables.MY_PREF, Context.MODE_PRIVATE)
        val userRole = sharedPreferences.getInt(Variables.USER_ROLE, 0)

        if (userRole == 1) {
            binding.addToCart.visibility = View.GONE
        } else if (userRole == 2) {
            binding.update.visibility = View.GONE
            binding.delete.visibility = View.GONE
        }

        binding.back1.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            startActivity(intent)
            finish()
        }

        binding.delete.setOnClickListener {
            val foodId = intent.getStringExtra(Variables.FF_ID)!!

            val db = FirebaseFirestore.getInstance()

            db.collection(Variables.FOOD_ITEM).document(foodId)
                .delete()
                .addOnSuccessListener {
                    Constant.showToast(this, Variables.FOOD_ITEM_DELETD)
                    val intent = Intent(this, MainActivity::class.java)
                    intent.flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                    startActivity(intent)
                    finish()
                }
                .addOnFailureListener { e ->
                    Constant.showToast(this, Variables.FOOD_ITEM_DELETD_NOT)
                }
        }

        if (type == Variables.CART) {
            binding.addToCart.visibility = View.GONE
            binding.checkout.visibility = View.VISIBLE

            binding.checkout.setOnClickListener {
                val randomIDGenerated = UUID.randomUUID().toString()
                val orderData = hashMapOf(
                    Variables.FF_NN to fName,
                    Variables.FF_QQ to qName,
                    Variables.FF_CC to cName,
                    Variables.FF_PP to pName,
                    Variables.FF_AA to amount,
                    Variables.FF_IMG_URL to iUrl,
                    Variables.FF_ID to randomIDGenerated,
                    Variables.FF_EE to restaurantId
                )
                val db = FirebaseFirestore.getInstance()
                db.collection(Variables.ORDER_LIST).document(randomIDGenerated)
                    .set(orderData)
                    .addOnSuccessListener { documentReference ->
                        Constant.showToast(this, Variables.ORDER_PLACED)
                        val intent = Intent(this, MainActivity::class.java)
                        intent.flags =
                            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        startActivity(intent)
                        finish()
                    }
                    .addOnFailureListener { e ->
                        Constant.showToast(this, Variables.ORDER_FAILED)
                    }
            }
        }

        binding.foodName.text = fName
        binding.foodQuant.text = qName
        binding.foodCity.text = cName
        binding.foodPla.text = pName
        Glide.with(this)
            .load(iUrl)
            .into(binding.foodImage)

        binding.update.setOnClickListener {
            val intent = Intent(this, UpdateFoodPage::class.java)
            intent.putExtra(Variables.FF_NN, fName)
            intent.putExtra(Variables.FF_QQ, qName)
            intent.putExtra(Variables.FF_AA, amount)
            intent.putExtra(Variables.FF_CC, cName)
            intent.putExtra(Variables.FF_PP, pName)
            intent.putExtra(Variables.FF_IMG_URL, iUrl)
            intent.putExtra(Variables.FF_ID, foodId)
            startActivity(intent)
        }


    }


    private fun updateBtn() {
        lifecycleScope.launch {
            val isInCart = foodDao.isFoodInCart(foodId)
            if (isInCart) {
                binding.addToCart.text = Variables.VIEW_CART
                binding.addToCart.setOnClickListener {
                    navigateToCartPage()
                }
            } else {
                binding.addToCart.text = Variables.ADD_TO_CART
                binding.addToCart.setOnClickListener {
                    addProductToCart()
                }
            }
        }
    }

    private fun addProductToCart() {
        val foodItem = FoodItem(
            foodName = fName ?: Variables.F_EMPTY,
            foodQuantity = qName ?: Variables.Q_EMPTY,
            foodCity = cName ?: Variables.C_EMPTY,
            foodPlace = pName ?: Variables.P_EMPTY,
            foodAmount = amount ?: Variables.A_EMPTY,
            imageUrl = iUrl ?: Variables.I_EMPTY,
            restaurantId = restaurantId!!,
            foodId = foodId!!
        )

        lifecycleScope.launch {
            foodDao.insertFood(foodItem)
            Constant.showToast(this@FoodDetailActivity, Variables.ADD_TO_CART)
            updateBtn()
        }
    }

    private fun navigateToCartPage() {
        val intent = Intent(this, CartActivity::class.java)
        startActivity(intent)
    }


}
